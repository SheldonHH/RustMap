fn main() {
    println!("{}", 'a' as u8);  // 输出"a"对应的ASCII码，即97
    println!("{}", 97 as char);  // 输出ASCII码97对应的字符，即'a'
}