fn inf() -> f64 {
    f64::INFINITY
}

fn main() {
    println!("{}", inf());
}