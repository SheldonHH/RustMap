fn test(a: i32, b: i32) -> i32 {
    a + b
}

fn main() {
    println!("{}", test(7, 12));
}